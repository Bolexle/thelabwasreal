Alex Holmes, A00820797, 1A, February 28th, 2014

This assignment is 100% complete.


------------------------
Question one (TriangleArea) status:

complete

------------------------
Question two (CylinderStats) status:

complete

------------------------
Question three (Bookshelf) status:

complete

------------------------
Question four (BoxTest) status:

complete

------------------------
Question five (TrafficLight) status:

complete
